<?php
declare(strict_types=1);

require __DIR__ . '/includes/bootstrap.php';

if (!app_has_config()) {
    app_redirect('setup-first-user.php');
}

try {
    $config = app_config();
    date_default_timezone_set((string)($config['app']['timezone'] ?? 'UTC'));
    app_boot_session();
    $pdo = app_pdo();
    if (!app_schema_is_installed($pdo) || !app_owner_exists($pdo)) {
        app_redirect('setup-first-user.php');
    }
} catch (Throwable) {
    app_redirect('setup-first-user.php');
}

if (app_current_user()) {
    app_redirect('index.php');
}

$error = null;
$return = (string)($_GET['return'] ?? $_POST['return'] ?? 'index.php');
if (!preg_match('/^[A-Za-z0-9_.?=&%-]+$/', $return) || str_contains($return, '..')) {
    $return = 'index.php';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    if (!app_verify_csrf($_POST['csrf_token'] ?? null)) {
        $error = 'The login form expired. Refresh the page and try again.';
    } else {
        $statement = $pdo->prepare(
            "SELECT u.*, om.organization_id
             FROM users u
             INNER JOIN organization_memberships om ON om.user_id = u.id AND om.status = 'active'
             WHERE u.email = :email AND u.archived_at IS NULL
             ORDER BY om.id ASC LIMIT 1"
        );
        $statement->execute(['email' => $email]);
        $user = $statement->fetch();
        $locked = $user && $user['locked_until'] && strtotime((string)$user['locked_until']) > time();
        $valid = $user && !$locked && $user['status'] === 'active' && password_verify($password, (string)$user['password_hash']);

        if (!$valid) {
            if ($user && !$locked) {
                $failed = (int)$user['failed_login_count'] + 1;
                $lockUntil = $failed >= 5 ? date('Y-m-d H:i:s.u', time() + 900) : null;
                $update = $pdo->prepare("UPDATE users SET failed_login_count = ?, locked_until = ? WHERE id = ?");
                $update->execute([$failed >= 5 ? 0 : $failed, $lockUntil, $user['id']]);
            }
            usleep(random_int(180000, 420000));
            $error = $locked ? 'This account is temporarily locked. Try again later.' : 'The email or password is incorrect.';
        } else {
            if (password_needs_rehash((string)$user['password_hash'], defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT)) {
                $rehash = password_hash($password, defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT);
                if (is_string($rehash)) {
                    $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")->execute([$rehash, $user['id']]);
                }
            }
            $pdo->prepare("UPDATE users SET failed_login_count = 0, locked_until = NULL, last_login_at = NOW(6) WHERE id = ?")->execute([$user['id']]);
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['organization_id'] = (int)$user['organization_id'];
            $_SESSION['authenticated_at'] = time();
            app_audit($pdo, (int)$user['organization_id'], (int)$user['id'], 'authentication.login', 'user', (string)$user['id']);
            app_redirect($return);
        }
    }
}

$brandName = (string)($config['app']['name'] ?? 'Restaurant Workspace');
try {
    $brandName = (string)($pdo->query("SELECT restaurant_name FROM brand_settings ORDER BY id ASC LIMIT 1")->fetchColumn() ?: $brandName);
} catch (Throwable) {
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= app_escape($brandName) ?> Login</title>
  <link rel="stylesheet" href="css/public.css">
</head>
<body>
  <main class="auth-shell">
    <section class="auth-brand-panel">
      <div>
        <a class="public-brand" href="landing.html"><span class="public-logo">RW</span><span><strong><?= app_escape($brandName) ?></strong><span>Training, hiring, and menu knowledge</span></span></a>
        <h1>Train the team. Protect the menu. Build better service.</h1>
        <p>Sign in with the account created by the store owner or an authorized administrator.</p>
      </div>
      <footer>Database authentication · Password hashes · Server-side sessions · Permission-based access</footer>
    </section>
    <section class="auth-form-panel">
      <div class="auth-card">
        <p class="eyebrow">Secure account access</p>
        <h2>Sign in</h2>
        <p>Use your restaurant account credentials.</p>
        <?php if ($error): ?><div class="form-message bad" style="margin-bottom:14px"><?= app_escape($error) ?></div><?php endif; ?>
        <form method="post" autocomplete="on">
          <input type="hidden" name="csrf_token" value="<?= app_escape(app_csrf_token()) ?>">
          <input type="hidden" name="return" value="<?= app_escape($return) ?>">
          <div class="field-wrap"><label for="email">Email address</label><input class="field" id="email" name="email" type="email" value="<?= app_escape($_POST['email'] ?? '') ?>" autocomplete="username" required autofocus></div>
          <div class="field-wrap"><label for="password">Password</label><input class="field" id="password" name="password" type="password" autocomplete="current-password" required></div>
          <button class="submit-button" type="submit">Sign in to workspace</button>
        </form>
      </div>
    </section>
  </main>
</body>
</html>
